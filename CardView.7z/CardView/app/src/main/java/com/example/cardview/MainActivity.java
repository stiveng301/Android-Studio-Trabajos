package com.example.cardview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    List<ListaElementos> Elemetos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
    }
    public void init(){
        Elemetos = new ArrayList<>();
        Elemetos.add(new ListaElementos("7B1FA2", "Stiven", "Medellin", "Bueno"));
        Elemetos.add(new ListaElementos("D5FF09", "Juan", "Medellin", "Malo"));
        Elemetos.add(new ListaElementos("880E4F", "Jacinto", "Medellin", "Nks"));
        Elemetos.add(new ListaElementos("7B1FA2", "Jose", "Medellin", "Szs"));

        ListAdapter listAdapter = new ListAdapter(Elemetos, this);
        RecyclerView recyclerView = findViewById(R.id.listrecycleview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(listAdapter);
    }

}