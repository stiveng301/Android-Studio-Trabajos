package com.example.cardview;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> {

    private List<ListaElementos> MisDatos;
    private LayoutInflater MyInflater;
    private Context MyContext;

    public ListAdapter(List<ListaElementos> ItemList, Context context) {

        this.MisDatos = ItemList;
        this.MyInflater = LayoutInflater.from(context);
        this.MyContext =  context;
    }

    @NonNull
    @Override
    public ListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View Vista = MyInflater.inflate(R.layout.list_elements, null);
        return new ListAdapter.ViewHolder(Vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ListAdapter.ViewHolder holder, int position) {
    holder.bindData(MisDatos.get(position));

    }

    @Override
    public int getItemCount() {
        return MisDatos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        ImageView IconImage;
        TextView Name, City, Status;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            IconImage = itemView.findViewById(R.id.IconoImageView);
            Name = itemView.findViewById(R.id.NameTextView);
            City = itemView.findViewById(R.id.CityTextView);
            Status = itemView.findViewById(R.id.Status);
        }

        void bindData(final ListaElementos item){
            IconImage.setColorFilter(Color.parseColor(item.getColor()), PorterDuff.Mode.SRC_IN);
            Name.setText(item.getNombre());
            City.getText(item.getCiudad());
            Status.getText(item.getEstado());

        }
    }
}
